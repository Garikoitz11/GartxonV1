package com.example.proyecto1.Fragments;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.util.Base64;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.proyecto1.ContentPrincipal;
import com.example.proyecto1.R;
import com.example.proyecto1.miBD;

import org.apache.commons.codec.DecoderException;
import org.apache.commons.codec.binary.Hex;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;

public class FragmentPerfil extends Fragment {

    private String email;
    private String contraseña;
    private String nombre;
    private String apellidos;
    private byte[] foto;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            email = getArguments().getString("email");
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_perfil, container, false);

        miBD GestorDB = new miBD (getContext(), "miBD", null, 2);
        SQLiteDatabase bd = GestorDB.getReadableDatabase();
        Cursor c = bd.rawQuery("SELECT * FROM Usuarios WHERE Email = '" + email + "'", null);
        if (c.moveToNext()) {
            contraseña = c.getString(1);
            nombre = c.getString(2);
            apellidos = c.getString(3);
            foto = c.getBlob(4);
        }
        c.close();
        bd.close();

        TextView textoEmail = (TextView) view.findViewById(R.id.emailPerfil);
        textoEmail.setText(email);
        TextView textoContraseña = (TextView) view.findViewById(R.id.contraseñaPerfil);
        textoContraseña.setText(contraseña);
        TextView textoNombre = (TextView) view.findViewById(R.id.nombrePerfil);
        textoNombre.setText(nombre);
        TextView textoApellidos = (TextView) view.findViewById(R.id.apellidosPerfil);
        textoApellidos.setText(apellidos);

        ImageView imagen = (ImageView) view.findViewById(R.id.imagenPerfil);
        byte[] blob = null;

        if (foto != null)
        {
            //Decodificamos en hexadecimal la foto
            String hexString = Hex.encodeHexString(foto);
            try {
                blob = Hex.decodeHex(hexString.toCharArray());
            } catch (DecoderException e) {

            }
            //La pasamos de byte que se guarda en la bd codificada en hex a bitmap para poder mostrarla
            Bitmap bmp = BitmapFactory.decodeByteArray(blob, 0 , blob.length);
            imagen.setImageBitmap(bmp);
        }

        final byte[] finalBlob = blob;
        Button botonEditarPerfil = (Button) view.findViewById(R.id.botonEditarPerfil);

        botonEditarPerfil.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Pasamos los datos a editar
                FragmentEditarPerfil fragmentEditarPerfil = new FragmentEditarPerfil();
                Bundle bundle = new Bundle();
                bundle.putString("email", email);
                bundle.putString("contraseña", contraseña);
                bundle.putString("nombre", nombre);
                bundle.putString("apellidos", apellidos);
                bundle.putByteArray("foto", finalBlob);
                fragmentEditarPerfil.setArguments(bundle);

                AppCompatActivity activity = (AppCompatActivity) view.getContext();
                FragmentManager fragmentManager = activity.getSupportFragmentManager();
                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                fragmentTransaction.replace(R.id.container, fragmentEditarPerfil);
                fragmentTransaction.commit();
            }
        });

        return view;
    }

}