package com.example.proyecto1.Fragments;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.example.proyecto1.ContentPrincipal;
import com.example.proyecto1.R;
import com.example.proyecto1.miBD;

import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import org.apache.commons.codec.binary.Hex;

public class FragmentEditarPerfil extends Fragment {

    private String email;
    private String contraseña;
    private String nombre;
    private String apellidos;
    ImageView imagen;
    TextView textoEmail;
    TextView textoContraseña;
    TextView textoNombre;
    TextView textoApellidos;
    Bitmap selectedImage;
    boolean imagenInsertada = false;
    byte[] foto;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            email = getArguments().getString("email");
            contraseña = getArguments().getString("contraseña");
            nombre = getArguments().getString("nombre");
            apellidos = getArguments().getString("apellidos");
            foto =  getArguments().getByteArray("foto");
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_editar_perfil, container, false);

        textoEmail = (TextView) view.findViewById(R.id.textoEmail);
        textoEmail.setText(email);
        textoContraseña = (TextView) view.findViewById(R.id.editTextContraseña);
        textoContraseña.setText(contraseña);
        textoNombre = (TextView) view.findViewById(R.id.editTextNombre);
        textoNombre.setText(nombre);
        textoApellidos = (TextView) view.findViewById(R.id.editTextApellidos);
        textoApellidos.setText(apellidos);
        imagen = (ImageView) view.findViewById(R.id.imagenEditarPerfil);

        if (foto != null) {
            Bitmap bmp = BitmapFactory.decodeByteArray(foto, 0 , foto.length);
            imagen.setImageBitmap(bmp);
        }

        Button botonEditarPerfil = (Button) view.findViewById(R.id.botonSeleccionarFoto);
        botonEditarPerfil.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(intent, 1234);
            }
        });

        Button botonGuardarPerfil = (Button) view.findViewById(R.id.botonGuardarPerfil);
        botonGuardarPerfil.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (imagenInsertada) {
                    Bitmap bitmap = selectedImage;
                    ByteArrayOutputStream out = new ByteArrayOutputStream();
                    bitmap.compress(Bitmap.CompressFormat.PNG, 0 , out);
                    byte[] blob = out.toByteArray();
                    String hexString = Hex.encodeHexString(blob);

                    miBD GestorDB = new miBD (getContext(), "miBD", null, 2);
                    SQLiteDatabase bd = GestorDB.getWritableDatabase();
                    bd.execSQL("UPDATE Usuarios SET Contraseña='"+textoContraseña.getText().toString()+"', Nombre='"+textoNombre.getText().toString()+"', Apellidos='"+textoApellidos.getText().toString()+ "', Foto=x'"+hexString+"' WHERE Email='"+email+"'");
                    bd.close();
                }
                else {
                    miBD GestorDB = new miBD (getContext(), "miBD", null, 2);
                    SQLiteDatabase bd = GestorDB.getWritableDatabase();
                    bd.execSQL("UPDATE Usuarios SET Contraseña='"+textoContraseña.getText().toString()+"', Nombre='"+textoNombre.getText().toString()+"', Apellidos='"+textoApellidos.getText().toString()+ "' WHERE Email='"+email+"'");
                    bd.close();
                }

                FragmentPerfil fragmentPerfil = new FragmentPerfil();
                Bundle bundle = new Bundle();
                bundle.putString("email", email);
                fragmentPerfil.setArguments(bundle);

                AppCompatActivity activity = (AppCompatActivity) view.getContext();
                FragmentManager fragmentManager = activity.getSupportFragmentManager();
                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                fragmentTransaction.replace(R.id.container, fragmentPerfil);
                fragmentTransaction.commit();

            }
        });

        return view;
    }

    public void onActivityResult(int requestCode, int resultCode, Intent data)
    {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == Activity.RESULT_OK && data != null) {
            Uri imageUri = data.getData();
            try {
                InputStream imagenStream = getContext().getContentResolver().openInputStream(imageUri);
                selectedImage = BitmapFactory.decodeStream(imagenStream);
                imagen.setImageBitmap(selectedImage);
            } catch (FileNotFoundException e) {
            }
            imagenInsertada = true;

        }else {
            int tiempo= Toast.LENGTH_SHORT;
            Toast aviso = Toast.makeText(getContext(), "No has seleccionado ninguna imagen", tiempo);
            aviso.show();
        }
    }
}