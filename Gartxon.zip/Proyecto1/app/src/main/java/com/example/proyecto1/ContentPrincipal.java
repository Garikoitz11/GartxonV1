package com.example.proyecto1;

import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.example.proyecto1.Dialogs.Idioma;
import com.example.proyecto1.Fragments.FragmentPerfil;
import com.example.proyecto1.Fragments.FragmentPreferencias;
import com.example.proyecto1.Fragments.FragmentPrincipal;
import com.google.android.material.navigation.NavigationView;

import java.util.Locale;

public class ContentPrincipal extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener, InterfaceIdioma{

    DrawerLayout drawerLayout;
    ActionBarDrawerToggle actionBarDrawerToggle;
    Toolbar toolbar;
    NavigationView navigationView;
    FragmentManager fragmentManager;
    FragmentTransaction fragmentTransaction;
    String email;
    String idiomaApp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //Obtenemos los parametros que recibe
        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            email= extras.getString("email");
            idiomaApp = extras.getString("idioma");
        }

        //Cambiamos el idioma al establecido o español por defecto. Se tiene que hacer al crearse
        Locale nuevaloc = new Locale(idiomaApp);
        Locale.setDefault(nuevaloc);
        Configuration configuration = getBaseContext().getResources().getConfiguration();
        configuration.setLocale(nuevaloc);
        configuration.setLayoutDirection(nuevaloc);
        Context context = getBaseContext().createConfigurationContext(configuration);
        getBaseContext().getResources().updateConfiguration(configuration, context.getResources().getDisplayMetrics());

        setContentView(R.layout.activity_menu);

        //Cargamos los elementos
        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        drawerLayout = findViewById(R.id.drawer_layout);
        navigationView = findViewById(R.id.elnavigationview);
        navigationView.setNavigationItemSelectedListener(this);

        actionBarDrawerToggle = new ActionBarDrawerToggle(this, drawerLayout, toolbar, R.string.iniciarSesion, R.string.contraseña);
        drawerLayout.addDrawerListener(actionBarDrawerToggle);
        actionBarDrawerToggle.setDrawerIndicatorEnabled(true);
        actionBarDrawerToggle.syncState();

        //Si tenemos un fragmento cargado por rotacion de pantalla
        if (savedInstanceState != null) {
            android.app.FragmentManager fragmentManager = getFragmentManager();
            android.app.Fragment savedFragment = fragmentManager.getFragment(savedInstanceState, "fragmentoActual");
            if (savedFragment != null) {
                fragmentManager.beginTransaction().replace(R.id.container, savedFragment).commit();
            }
        }

        //Si es la primera vez que se carga
        else {
            FragmentPrincipal fragmentPrincipal = new FragmentPrincipal();
            Bundle bundle = new Bundle();
            bundle.putString("tipo", "todos");
            fragmentPrincipal.setArguments(bundle);

            fragmentManager = getSupportFragmentManager();
            fragmentTransaction = fragmentManager.beginTransaction();
            fragmentTransaction.replace(R.id.container, fragmentPrincipal);
            fragmentTransaction.commit();
        }

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.toolbar_opciones, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int i = item.getItemId();

        //Si pulsamos logout nos lleva a login
        if(i==R.id.logout)
        {
            Intent intent = new Intent(this, Login.class);
            startActivity(intent);
        }
        return true;
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        drawerLayout.closeDrawer(GravityCompat.START);
        //Miramos cual de todas las opcioes del navigation view se selecciona y catga el fragmento correspondiente
        if(item.getItemId() == R.id.home) {
            FragmentPrincipal fragmentPrincipal = new FragmentPrincipal();
            Bundle bundle = new Bundle();
            bundle.putString("tipo", "todos");
            fragmentPrincipal.setArguments(bundle);

            fragmentManager = getSupportFragmentManager();
            fragmentTransaction = fragmentManager.beginTransaction();
            fragmentTransaction.replace(R.id.container, fragmentPrincipal);
            fragmentTransaction.commit();
        }

        else if(item.getItemId() == R.id.movil) {
            FragmentPrincipal fragmentPrincipal = new FragmentPrincipal();
            Bundle bundle = new Bundle();
            bundle.putString("tipo", "movil");
            fragmentPrincipal.setArguments(bundle);

            fragmentManager = getSupportFragmentManager();
            fragmentTransaction = fragmentManager.beginTransaction();
            fragmentTransaction.replace(R.id.container, fragmentPrincipal);
            fragmentTransaction.commit();
        }

        else if(item.getItemId() == R.id.ordenador) {
            FragmentPrincipal fragmentPrincipal = new FragmentPrincipal();
            Bundle bundle = new Bundle();
            bundle.putString("tipo", "ordenador");
            fragmentPrincipal.setArguments(bundle);

            fragmentManager = getSupportFragmentManager();
            fragmentTransaction = fragmentManager.beginTransaction();
            fragmentTransaction.replace(R.id.container, fragmentPrincipal);
            fragmentTransaction.commit();
        }

        else if(item.getItemId() == R.id.consola) {
            FragmentPrincipal fragmentPrincipal = new FragmentPrincipal();
            Bundle bundle = new Bundle();
            bundle.putString("tipo", "consola");
            fragmentPrincipal.setArguments(bundle);

            fragmentManager = getSupportFragmentManager();
            fragmentTransaction = fragmentManager.beginTransaction();
            fragmentTransaction.replace(R.id.container, fragmentPrincipal);
            fragmentTransaction.commit();
        }

        else if(item.getItemId() == R.id.otros) {
            FragmentPrincipal fragmentPrincipal = new FragmentPrincipal();
            Bundle bundle = new Bundle();
            bundle.putString("tipo", "otros");
            fragmentPrincipal.setArguments(bundle);

            fragmentManager = getSupportFragmentManager();
            fragmentTransaction = fragmentManager.beginTransaction();
            fragmentTransaction.replace(R.id.container, fragmentPrincipal);
            fragmentTransaction.commit();
        }

        else if(item.getItemId() == R.id.perfil) {
            fragmentManager = getSupportFragmentManager();
            fragmentTransaction = fragmentManager.beginTransaction();

            FragmentPerfil fragmentPerfil = new FragmentPerfil();
            Bundle bundle = new Bundle();
            bundle.putString("email", email);
            fragmentPerfil.setArguments(bundle);
            fragmentTransaction.replace(R.id.container, fragmentPerfil);
            fragmentTransaction.commit();
        }
        else if(item.getItemId() == R.id.idioma) {
            DialogFragment newFragment = new Idioma();
            newFragment.show(getSupportFragmentManager(), "SeleccionContenidoPrincipal");
        }
        else if(item.getItemId() == R.id.preferencias) {
            fragmentManager = getSupportFragmentManager();
            fragmentTransaction = fragmentManager.beginTransaction();
            fragmentTransaction.replace(R.id.container, new FragmentPreferencias());
            fragmentTransaction.commit();
        }
        return false;
    }

    public void onSaveInstanceState(Bundle outState) {
        //Cuando se rota guarda email y fragmento cargado en la actividad
        super.onSaveInstanceState(outState);
        outState.putString("email",  email);
        android.app.FragmentManager fragmentManager = getFragmentManager();
        android.app.Fragment currentFragment = fragmentManager.findFragmentById(R.id.container);
        if (currentFragment != null) {
            fragmentManager.putFragment(outState, "fragmentoActual", currentFragment);
        }
    }

    @Override
    public void cambiarIdioma(String idioma) {
        //Cuando se selecciona un idioma se carga y envia de nuevo a la pagina principal
        idiomaApp = idioma;
        getIntent().putExtra("idioma" , idiomaApp);
        finish();
        startActivity(getIntent());
    }

    @Override
    public void onBackPressed() {
        // No permitir que el usuario regrese a la actividad anterior para que no haga logout
    }
}
