package com.example.proyecto1;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.DialogFragment;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;

import android.Manifest;
import android.app.AlertDialog;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Locale;
import java.util.Random;

public class Registro extends AppCompatActivity {

    static final String BROADCAST_ACTIVITY_CLOSE = "com.example.ACTIVITY_CLOSE_BROADCAST";
    String emailIntroducido;
    String contraseñaIntroducida;
    //String numeroVerificacion = null;
    String idiomaApp;


    //Lo comentado de codigo es parte del codigo de verificacion que no he podido implementar debido a problemas con el broadcast y la rotacion.
    //Si no se produce rotacion en esta pantalla funciona perfecto
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Bundle extras = getIntent().getExtras();

        //Obtieene datos guadrados onSave
        if (savedInstanceState!= null) {
            //numeroVerificacion = savedInstanceState.getString("numeroVerificacion");
            emailIntroducido = savedInstanceState.getString("emailIntroducido");
            contraseñaIntroducida = savedInstanceState.getString("contraseñaIntroducida");
            idiomaApp = savedInstanceState.getString("idioma");
        }
        //obtiene datos del login por ejemplo
        else if (extras != null) {
            idiomaApp = extras.getString("idioma");
        }

        //Cambiamos el idioma al establecido o español por defecto. Se tiene que hacer al crearse
        Locale nuevaloc = new Locale(idiomaApp);
        Locale.setDefault(nuevaloc);
        Configuration configuration = getBaseContext().getResources().getConfiguration();
        configuration.setLocale(nuevaloc);
        configuration.setLayoutDirection(nuevaloc);
        Context context = getBaseContext().createConfigurationContext(configuration);
        getBaseContext().getResources().updateConfiguration(configuration, context.getResources().getDisplayMetrics());

        setContentView(R.layout.activity_registro);

        //Solicita permisos de poner notificaciones
        if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.POST_NOTIFICATIONS)!=
                PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new
                    String[]{Manifest.permission.POST_NOTIFICATIONS}, 11);
        }

//        LocalBroadcastManager broadcastManager = LocalBroadcastManager.getInstance(this);
//        IntentFilter intentFilter = new IntentFilter();
//        intentFilter.addAction(BROADCAST_ACTIVITY_CLOSE);
//        broadcastManager.registerReceiver(broadcastReceiver, intentFilter);

        Button volver = (Button) findViewById(R.id.volverRegistro);
        Button registrarse = (Button) findViewById(R.id.OKRegistro);

        registrarse.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                EditText contraseña = (EditText) findViewById(R.id.contraseñaRegistro);
                EditText repetirContraseña = (EditText) findViewById(R.id.repetirContraseñaRegistro);
                contraseñaIntroducida = contraseña.getText().toString();
                String contraseñaRepetidaIntroducida = repetirContraseña.getText().toString();

                if(contraseñaIntroducida.equals(contraseñaRepetidaIntroducida)) {

//                    NotificationManager elManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
//                    NotificationCompat.Builder elBuilder = new NotificationCompat.Builder(getApplicationContext(), "IdCanal");

//                    Random generador = new Random();
//                    numeroVerificacion = String.valueOf(String.format("%04d", generador.nextInt(10000)));

//                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
//                        NotificationChannel elCanal = new NotificationChannel("IdCanal", "NombreCanal",
//                                NotificationManager.IMPORTANCE_DEFAULT);
//
//                        elBuilder.setSmallIcon(R.drawable.ic_gartxon);
//                        elBuilder.setContentTitle("Código de verificación");
//
//                        elBuilder.setContentText("El código que ha de introducir es: " + numeroVerificacion);
//                        elBuilder.setVibrate(new long[]{0, 1000, 500, 1000});
//                        elBuilder.setAutoCancel(true);
//
//                        elCanal.setDescription("Código de verificación");
//                        elCanal.enableLights(true);
//                        elCanal.setLightColor(Color.WHITE);
//                        elCanal.setVibrationPattern(new long[]{0, 1000, 500, 1000});
//                        elCanal.enableVibration(true);
//                        elManager.createNotificationChannel(elCanal);
//                    }
//                    elManager.notify(1, elBuilder.build());

                    EditText email = (EditText) findViewById(R.id.emailRegistro);
                    emailIntroducido = email.getText().toString();

//                    Bundle bundle = new Bundle();
//                    bundle.putString("codigo", numeroVerificacion);

//                    DialogFragment newFragment = new Verificacion();
//                    newFragment.setArguments(bundle);
//                    newFragment.show(getSupportFragmentManager(), "Verificacion");

                    //Guarda el usuario
                    try {
                        miBD GestorDB = new miBD(getApplicationContext(), "miBD", null, 2);
                        SQLiteDatabase bd = GestorDB.getWritableDatabase();
                        bd.execSQL("INSERT INTO Usuarios ('Email', 'Contraseña') VALUES ('" + emailIntroducido + "','" + contraseñaIntroducida + "')");
                        bd.close();
                        Intent intent = new Intent();
                        intent.putExtra("email", emailIntroducido);
                        intent.putExtra("contraseña", contraseñaIntroducida);
                        Registro.this.setResult(RESULT_OK, intent);
                        finish();
                    }
                    catch (Exception e) {
                        //Aviso de error por coincidir el usuario p.e.
                        int tiempo= Toast.LENGTH_SHORT;
                        Toast aviso = Toast.makeText(getApplicationContext(), "¡Error!", tiempo);
                        aviso.show();
                    }


                }
                else{
                    //Aviso error contras
                    int tiempo= Toast.LENGTH_SHORT;
                    Toast aviso = Toast.makeText(getApplicationContext(), "¡CUIDADO! Las contraseñas no coinciden", tiempo);
                    aviso.show();
                }
            }
        });

        volver.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Volver sin datos
                Intent intent=new Intent();
                intent.putExtra("email", "");
                intent.putExtra("contraseña", "");
                setResult(RESULT_OK, intent);
                finish();
            }
        });
    }

//    private BroadcastReceiver broadcastReceiver = new BroadcastReceiver() {
//        @Override
//        public void onReceive(Context context, Intent i) {
//            if(i.getAction().equals(BROADCAST_ACTIVITY_CLOSE)) {
//                miBD GestorDB = new miBD(getApplicationContext(), "miBD", null, 2);
//                SQLiteDatabase bd = GestorDB.getWritableDatabase();
//                bd.execSQL("INSERT INTO Usuarios ('Email', 'Contraseña') VALUES ('" + emailIntroducido + "','" + contraseñaIntroducida + "')");
//                bd.close();
//                Intent intent = new Intent();
//                intent.putExtra("email", emailIntroducido);
//                intent.putExtra("contraseña", contraseñaIntroducida);
//                Registro.this.setResult(RESULT_OK, intent);
//                finish();
//            }
//        }
//    };

    //Guardamos los datos de interes antes de destruir la actividad por la rotacion de pantalla
    @Override
    protected void onSaveInstanceState (Bundle savedInstanceState) {
        //Guarda lo deseado al hacer rotacion etc
        super.onSaveInstanceState(savedInstanceState);
        EditText email = (EditText) findViewById(R.id.emailRegistro);
        savedInstanceState.putString("emailIntroducido",  email.getText().toString());
        EditText contraseña = (EditText) findViewById(R.id.contraseñaRegistro);
        savedInstanceState.putString("contraseñaIntroducida",  contraseña.getText().toString());
        savedInstanceState.putString("idioma",  idiomaApp);
        //savedInstanceState.putString("numeroVerificacion",  numeroVerificacion);
    }
}