package com.example.proyecto1;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.DialogFragment;
import androidx.preference.PreferenceManager;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.example.proyecto1.Dialogs.Idioma;

import java.util.Locale;

public class Login extends AppCompatActivity implements InterfaceIdioma {

    String idiomaApp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Bundle extras = getIntent().getExtras();

        //Miramos los datos guardados cuando hay rotacion de pantalla
        if (savedInstanceState!= null) {
            idiomaApp = savedInstanceState.getString("idioma");
        }
        //Miramos los datos guardados cuando se pulsa y boton y se hace finish (No pasa por onSaveInstance)
        else if (extras != null) {
            idiomaApp = extras.getString("idioma");
        }
        //Miramos el fichero de preferencias en caso de ser la primera vez que se inicia la aplicación
        else {
            SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);
            idiomaApp = prefs.getString("idiomaPrefs","es");
        }

        //Cambiamos el idioma al establecido o español por defecto. Se tiene que hacer al crearse
        Locale nuevaloc = new Locale(idiomaApp);
        Locale.setDefault(nuevaloc);
        Configuration configuration = getBaseContext().getResources().getConfiguration();
        configuration.setLocale(nuevaloc);
        configuration.setLayoutDirection(nuevaloc);
        Context context = getBaseContext().createConfigurationContext(configuration);
        getBaseContext().getResources().updateConfiguration(configuration, context.getResources().getDisplayMetrics());

        setContentView(R.layout.activity_login);

        //Obtenemos elementos
        Button iniciarSesion = (Button) findViewById(R.id.iniciarSesionLogin);
        Button registro = (Button) findViewById(R.id.RegistroLogin);
        ImageButton twitter = (ImageButton) findViewById(R.id.twitter);
        EditText email = (EditText) findViewById(R.id.emailLogin);
        EditText contraseña = (EditText) findViewById(R.id.contraseñaLogin);
        ImageButton apagar = (ImageButton) findViewById(R.id.apagar);
        ImageButton idioma = (ImageButton) findViewById(R.id.idioma);

        apagar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Nos saca de la app
                Intent homeIntent = new Intent(Intent.ACTION_MAIN);
                homeIntent.addCategory( Intent.CATEGORY_HOME );
                homeIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(homeIntent);
            }
        });

        idioma.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Nos abre el dialog idiomas
                DialogFragment newFragment = new Idioma();
                newFragment.show(getSupportFragmentManager(), "SeleccionIdioma");
            }
        });

        ActivityResultLauncher<Intent> startActivityIntent =
                registerForActivityResult(new
                                ActivityResultContracts.StartActivityForResult(),
                        new ActivityResultCallback<ActivityResult>() {
                            @Override
                            public void onActivityResult(ActivityResult result) {

                                if (result.getResultCode() == RESULT_OK) {
                                    //Obtiene usuario o contraseña si registro OK
                                    email.setText(result.getData().getStringExtra("email"));
                                    contraseña.setText(result.getData().getStringExtra("contraseña"));
                                }
                            }
                        });

        iniciarSesion.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                boolean existe = false;
                //Nos cierra el teclado
                View focus = getCurrentFocus();
                if (focus != null) {
                    InputMethodManager imm = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
                    imm.hideSoftInputFromWindow(focus.getWindowToken(), 0);
                }
                //Comprueba si existe usuario
                String emailIntroducido = email.getText().toString();
                String contraseñantroducida = contraseña.getText().toString();
                miBD GestorDB = new miBD (getBaseContext(), "miBD", null, 2);
                SQLiteDatabase bd = GestorDB.getReadableDatabase();
                Cursor c = bd.rawQuery("SELECT * FROM Usuarios WHERE Email = '" + emailIntroducido + "' AND Contraseña = '" + contraseñantroducida + "'", null);
                Intent i = null;
                if (c.moveToNext()) {
                    //Si devuelve algo abre la app
                    existe = true;
                    i = new Intent(getBaseContext(), ContentPrincipal.class);
                    i.putExtra("email", c.getString(0));
                    i.putExtra("idioma", idiomaApp);
                }
                c.close();
                bd.close();
                if(existe) {
                    startActivity(i);
                }
                else {
                    //Sino lanza mensaje
                    int tiempo= Toast.LENGTH_SHORT;
                    Toast aviso = Toast.makeText(getApplicationContext(), getResources().getString(R.string.usuarioContraseña), tiempo);
                    aviso.show();
                }
            }
        });

        registro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Abre registro
                Intent i = new Intent (getBaseContext(), Registro.class);
                i.putExtra("idioma", idiomaApp);
                startActivityIntent.launch(i); ;
            }
        });

        twitter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = null;
                try{
                    //Si el usuario tiene twitter instalado lo abre en la app
                    getBaseContext().getPackageManager().getPackageInfo("com.twitter.android", 0);
                    intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://twitter.com/gartxon"));
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                } catch (Exception e) {
                    //Sino lo abre en chrome o donde sea
                    intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://twitter.com/gartxon"));
                }
                startActivity(intent);
            }
        });
    }

    @Override
    public void cambiarIdioma(String idioma) {
        if (idioma != idiomaApp) {
            //Recibe que se ha seleccionado un idioma y cual ha sido del dialogo
            idiomaApp = idioma;
            getIntent().putExtra("idioma" , idiomaApp);
            finish();
            startActivity(getIntent());
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle savedInstanceState) {
        //guarda el idioma si hay rotacion de pantalla, cambio a modo oscuro, etc
        super.onSaveInstanceState(savedInstanceState);
        savedInstanceState.putString("idioma", idiomaApp);
    }
}