package com.example.proyecto1.Fragments;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.preference.PreferenceManager;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.proyecto1.ContentPrincipal;
import com.example.proyecto1.Dialogs.Compra;
import com.example.proyecto1.Login;
import com.example.proyecto1.R;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

public class FragmentProducto extends Fragment {

    String nombreProducto;
    String precioProducto;
    String descripcionProducto;
    String fotoProducto;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_producto, container, false);

        Bundle extras = getArguments();
        String codigoProducto = extras.getString("codigo");
        String tipoProducto = extras.getString("tipo");

        InputStream fich;
        BufferedReader buff;

        //Lee el fichero segun el filtro para la muestra de los detalles del producto
        if (tipoProducto.equals("otros")) {
            fich = getResources().openRawResource(R.raw.otros);
            buff = new BufferedReader(new InputStreamReader(fich));
        }
        else if (tipoProducto.equals("movil")) {
            fich = getResources().openRawResource(R.raw.moviles);
            buff = new BufferedReader(new InputStreamReader(fich));
        }
        else if (tipoProducto.equals("ordenador")) {
            fich = getResources().openRawResource(R.raw.ordenadores);
            buff = new BufferedReader(new InputStreamReader(fich));
        }
        else if (tipoProducto.equals("consola")) {
            fich = getResources().openRawResource(R.raw.consolas);
            buff = new BufferedReader(new InputStreamReader(fich));
        }
        else {
            fich = getResources().openRawResource(R.raw.productos);
            buff = new BufferedReader(new InputStreamReader(fich));
        }

        try {
            //Lee el fichero
            String linea = buff.readLine();
            while(linea != null){
                if(linea.equals(codigoProducto))
                {
                    linea = buff.readLine();
                    nombreProducto = linea;
                    linea = buff.readLine();
                    precioProducto = linea;
                    linea = buff.readLine();
                    descripcionProducto = linea;
                    linea = buff.readLine();
                    fotoProducto = linea;
                }
                linea = buff.readLine();
            }
            fich.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        TextView textoNombre = (TextView) view.findViewById(R.id.tituloProducto);
        textoNombre.setText(nombreProducto);
        TextView textoPrecio = (TextView) view.findViewById(R.id.precioProducto);
        textoPrecio.setText(precioProducto);
        TextView textoDescripcion = (TextView) view.findViewById(R.id.descripcionProducto);
        textoDescripcion.setText(descripcionProducto);
        Button pagar = (Button) view.findViewById(R.id.button2);

        pagar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Si decide comprar
                SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(getContext());
                Boolean esMayorEdad = prefs.getBoolean("mayorEdad", false);

                //Solo deja si en las preferencias ponemos mayor de edad
                if(esMayorEdad){
                    //Generamos dialogo de informacion de la factura
                    DialogFragment newFragment = new Compra();
                    newFragment.show(getChildFragmentManager(), "Compra");

                    //Generamos la notificacion de la factura
                    NotificationManager elManager = (NotificationManager) getActivity().getSystemService(Context.NOTIFICATION_SERVICE);
                    NotificationCompat.Builder elBuilder = new NotificationCompat.Builder(getActivity().getApplicationContext(), "IdCanal");

                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        NotificationChannel elCanal = new NotificationChannel("IdCanal", "NombreCanal",
                                NotificationManager.IMPORTANCE_DEFAULT);

                        elBuilder.setSmallIcon(R.drawable.ic_gartxon);
                        elBuilder.setContentTitle(getResources().getString(R.string.factura));

                        String nombreFactura = prefs.getString("nombreFactura", getResources().getString(R.string.anonimo));

                        if(nombreFactura.equals("")) {
                            nombreFactura = getResources().getString(R.string.anonimo);
                        }

                        elBuilder.setContentText(nombreFactura + " " + getResources().getString(R.string.compra) + " " + nombreProducto + getResources().getString(R.string.precioCompra) + " " + precioProducto);
                        elBuilder.setVibrate(new long[]{0, 1000, 500, 1000});
                        elBuilder.setAutoCancel(true);

                        //Generamos el pending intent que se ejecutara cuando se pulse en el boton que volvera a comprar
                        Intent comprarIntent = new Intent(getContext(), Login.class);
                        PendingIntent pComprar;
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                            pComprar = PendingIntent.getActivity(getContext(),
                                    0, comprarIntent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
                        }else {
                            pComprar = PendingIntent.getActivity(getContext(),
                                    0, comprarIntent, PendingIntent.FLAG_UPDATE_CURRENT);
                        }

                        //Generamos el pending intent que se ejecutara cuando se pulse en el boton que saldra de la aplicacion
                        Intent salirIntent = new Intent(Intent.ACTION_MAIN);
                        salirIntent.addCategory( Intent.CATEGORY_HOME );
                        salirIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        PendingIntent pSalir;
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                            pSalir = PendingIntent.getActivity(getContext(),
                                    0, salirIntent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
                        }else {
                            pSalir = PendingIntent.getActivity(getContext(),
                                    0, salirIntent, PendingIntent.FLAG_UPDATE_CURRENT);
                        }

                        //Los añadimos
                        elBuilder.addAction(android.R.drawable.ic_menu_add, "Login", pComprar);
                        elBuilder.addAction(android.R.drawable.ic_menu_delete, getResources().getString(R.string.salir), pSalir);

                        elCanal.setDescription("Código de verificación");
                        elCanal.enableLights(true);
                        elCanal.setLightColor(Color.WHITE);
                        elCanal.setVibrationPattern(new long[]{0, 1000, 500, 1000});
                        elCanal.enableVibration(true);
                        elManager.createNotificationChannel(elCanal);
                    }
                    elManager.notify(1, elBuilder.build());
                }
                else {
                    int tiempo= Toast.LENGTH_SHORT;
                    Toast aviso = Toast.makeText(getContext(), getResources().getString(R.string.mayorEdadCompra), tiempo);
                    aviso.show();
                }
            }
        });

        //Añadimos la foto
        ImageView foto = (ImageView) view.findViewById(R.id.imagenProducto);
        int drawableResourceId = this.getResources().getIdentifier(fotoProducto, "drawable", getContext().getPackageName());
        foto.setImageResource(drawableResourceId);

        return view;
    }

}