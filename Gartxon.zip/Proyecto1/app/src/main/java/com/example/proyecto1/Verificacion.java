package com.example.proyecto1;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;

public class Verificacion extends DialogFragment{

    //No he podido utilizalo al final por problemas con la rotacion ya que perdia el contexto y no he sido capaz de solucionarlo
    //El dialogo obtenia el codigo de verificacion random y controlaba que lo insertase el usuario. Sino no dejaba registrar
    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        super.onCreateDialog(savedInstanceState);

        String numeroVerificacion = this.getArguments().getString("codigo");
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setTitle("Introduce el código de verificación");
        LayoutInflater inflater = getLayoutInflater();
        View elaspecto = inflater.inflate(R.layout.codigo_verificacion,null);
        builder.setView(elaspecto);
        EditText codigo = (EditText) elaspecto.findViewById(R.id.introducirCodigo);
        Button botonCodigo = (Button) elaspecto.findViewById(R.id.botonAceptarCodigo);

        botonCodigo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (codigo.getText().toString().equals(numeroVerificacion)) {
                    Intent RTReturn = new Intent(Registro.BROADCAST_ACTIVITY_CLOSE);
                    LocalBroadcastManager.getInstance(getContext()).sendBroadcast(RTReturn);
                }
            }
        });
        AlertDialog alert = builder.create();
        alert.setCanceledOnTouchOutside(false);
        return alert;
    }
}