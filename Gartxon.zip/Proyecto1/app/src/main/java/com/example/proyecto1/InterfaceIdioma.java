package com.example.proyecto1;

//Para que el dialogo de idioma pueda comunicarse
public interface InterfaceIdioma {
    void cambiarIdioma(String idioma);
}
