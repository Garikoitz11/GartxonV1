package com.example.proyecto1;

public interface InterfaceIdioma {
    void cambiarIdioma(String idioma);
}
